git clone https://github.com/h2danilofatec/projeto-1semestre-2025.git

git config –global user.name “h2danilofatec”

git config –global user.email “danilo.valim01@fatecitapetininga.edu.br”