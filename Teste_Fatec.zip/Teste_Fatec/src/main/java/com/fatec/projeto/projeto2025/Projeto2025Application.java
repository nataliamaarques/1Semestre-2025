package com.fatec.projeto.projeto2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto2025Application {

	public static void main(String[] args) {
		SpringApplication.run(Projeto2025Application.class, args);
	}

}
